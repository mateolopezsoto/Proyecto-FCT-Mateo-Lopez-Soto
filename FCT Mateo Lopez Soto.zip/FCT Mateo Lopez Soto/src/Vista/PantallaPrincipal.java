package Vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PantallaPrincipal {

	private JFrame frmPantallaPrincipal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaPrincipal window = new PantallaPrincipal();
					window.frmPantallaPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PantallaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPantallaPrincipal = new JFrame();
		frmPantallaPrincipal.setTitle("Pantalla principal");
		frmPantallaPrincipal.setBounds(100, 100, 450, 300);
		frmPantallaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPantallaPrincipal.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JMenuBar menuBar = new JMenuBar();
		frmPantallaPrincipal.setJMenuBar(menuBar);
		
		JMenu idiomaMenu = new JMenu("Idioma");
		menuBar.add(idiomaMenu);
		
		JMenuItem castellanoMenuItem = new JMenuItem("Castellano");
		idiomaMenu.add(castellanoMenuItem);
		
		JMenuItem gallegoMenuItem = new JMenuItem("Gallego");
		idiomaMenu.add(gallegoMenuItem);
		
		JMenu ayudaMenu = new JMenu("Ayuda");
		menuBar.add(ayudaMenu);
		
		JMenuItem ayudaMenuItem = new JMenuItem("Ver ayuda");
		ayudaMenu.add(ayudaMenuItem);
		
		JMenu informesMenu = new JMenu("Informes");
		menuBar.add(informesMenu);
		
		JMenuItem informeColeccionesMenuItem = new JMenuItem("Informe colecciones");
		informesMenu.add(informeColeccionesMenuItem);
		
		JMenuItem informeComicsMenuItem = new JMenuItem("Informe comics");
		informesMenu.add(informeComicsMenuItem);
		
		JMenuItem informeFiltrosMenuItem = new JMenuItem("Informes con filtros");
		informeFiltrosMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InformeFiltros inf = new InformeFiltros();
				inf.setVisible(true);
			}
		});
		informesMenu.add(informeFiltrosMenuItem);
		
		JMenu gestionMenu = new JMenu("Gesti\u00F3n");
		menuBar.add(gestionMenu);
		
		JMenu coleccionesMenu = new JMenu("Colecciones");
		gestionMenu.add(coleccionesMenu);
		
		JMenuItem nuevaColeccionMenuItem = new JMenuItem("Nueva colecci\u00F3n");
		nuevaColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NuevaColeccion nc = new NuevaColeccion();
				nc.setVisible(true);
			}
		});
		coleccionesMenu.add(nuevaColeccionMenuItem);
		
		JMenuItem eliminarColeccionMenuItem = new JMenuItem("Eliminar colecci\u00F3n");
		eliminarColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EliminarColeccion ec = new EliminarColeccion();
				ec.setVisible(true);
			}
		});
		coleccionesMenu.add(eliminarColeccionMenuItem);
		
		JMenuItem tablaColeccionMenuItem = new JMenuItem("Tabla maestra");
		tablaColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TablaMaestraColecciones tmc = new TablaMaestraColecciones();
				tmc.setVisible(true);
			}
		});
		coleccionesMenu.add(tablaColeccionMenuItem);
		
		JMenu comicsMenu = new JMenu("Comics");
		gestionMenu.add(comicsMenu);
		
		JMenuItem nuevoComicMenuItem = new JMenuItem("Nuevo comic");
		nuevoComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NuevoComic nco = new NuevoComic();
				nco.setVisible(true);
			}
		});
		comicsMenu.add(nuevoComicMenuItem);
		
		JMenuItem eliminarComicMenuItem = new JMenuItem("Eliminar comic");
		eliminarComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EliminarComic eco = new EliminarComic();
				eco.setVisible(true);
			}
		});
		comicsMenu.add(eliminarComicMenuItem);
		
		JMenuItem tablaComicMenuItem = new JMenuItem("Tabla maestra");
		tablaComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TablaMaestraComics tmco = new TablaMaestraComics();
				tmco.setVisible(true);
			}
		});
		comicsMenu.add(tablaComicMenuItem);
	}

}
