package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 * Esta clase es la que servir� para conectar con la BBDD
 * @author Usuario
 *
 */
public class ConexionDatos {

	public Statement consulta;
	public ResultSet resultado;
	
	/**
	 * Este m�todo carga el driver de la base de datos de MySQL
	 * @throws ClassNotFoundException
	 */
	public void CargarDriver() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}
	
	/**
	 * En este m�todo obtenemos la conexi�n para realizar consultas en la base de datos
	 * @return c Es una conexi�n que utiliza el driver de la BBDD despu�s de que le pasemos la url y el nombre y contrase�a de la base
	 * @throws SQLException
	 */
	public Connection obtenerConexion() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/libreria";
		String usuario = "root";
		String pass = "abc123";
		Connection c = DriverManager.getConnection(url, usuario, pass);
		return c;
	}
	
	public void InformeComics() {
		String informe = "./Informes/InformeComics.jrxml";
		
		try {
			Connection conexion = obtenerConexion();
			Statement s = conexion.createStatement();
			ResultSet rs = s.executeQuery("SELECT idComic, nombre_comic, estado, fecha_adquisicion, idColeccion FROM comics");
			JRResultSetDataSource ds = new JRResultSetDataSource(rs);
			
			JasperReport report = JasperCompileManager.compileReport(informe);
			
			JasperPrint visor = JasperFillManager.fillReport(report, null, ds);
			
			JasperViewer.viewReport(visor, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void InformeColecciones() {
		String informe = "./Informes/InformeColecciones.jrxml";
		
		try {
			Connection conexion = obtenerConexion();
			Statement s = conexion.createStatement();
			ResultSet rs = s.executeQuery("SELECT idColeccion, nombre_coleccion FROM colecciones");
			JRResultSetDataSource ds = new JRResultSetDataSource(rs);
			
			JasperReport report = JasperCompileManager.compileReport(informe);
			
			JasperPrint visor = JasperFillManager.fillReport(report, null, ds);
			
			JasperViewer.viewReport(visor, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void InformeNombreComic() {
		String informe = "./Informes/InformeNombreComic.jrxml";
		
		try {
			Connection conexion = obtenerConexion();
			Statement s = conexion.createStatement();
			ResultSet rs = s.executeQuery("SELECT idComic, nombre_comic, estado, fecha_adquisicion, idColeccion FROM reservas WHERE nombre = ?");
			JRResultSetDataSource ds = new JRResultSetDataSource(rs);
			
			JasperReport report = JasperCompileManager.compileReport(informe);
			
			JasperPrint visor = JasperFillManager.fillReport(report, null, ds);
			
			JasperViewer.viewReport(visor, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
