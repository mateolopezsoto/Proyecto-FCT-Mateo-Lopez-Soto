package Modelo;

import java.sql.Date;

public class Comic {
	private int idComic;
	private String nombre_comic;
	private String estado;
	private Date fecha_adquisicion;
	private int idColeccion;
	
	Comic (int id, String nombre, String estado, Date fecha, int idC) {
		this.idComic = id;
		this.nombre_comic = nombre;
		this.estado = estado;
		this.fecha_adquisicion = fecha;
		this.idColeccion = idC;
	}
	
	Comic (String nombre, String estado, Date fecha, int idC) {
		this.nombre_comic = nombre;
		this.estado = estado;
		this.fecha_adquisicion = fecha;
		this.idColeccion = idC;
	}
	
	Comic () {}
	
	public String GetNombreComic () {
		return nombre_comic;
	}
	
	public void SetNombreComic (String nombre) {
		this.nombre_comic = nombre;
	}
	
	public String GetEstado () {
		return estado;
	}
	
	public void SetEstado (String estado) {
		this.estado = estado;
	}
	
	public Date GetFechaAdquisicion () {
		return fecha_adquisicion;
	}
	
	public void SetFechaAdquisicion (Date fecha) {
		this.fecha_adquisicion = fecha;
	}
	
	public int GetIdComic () {
		return idComic;
	}
	
	public void SetIdComic (int id) {
		this.idComic = id;
	}
	
	public int GetIdColeccion () {
		return idColeccion;
	}
	
	public void SetIdColeccion (int id) {
		this.idColeccion = id;
	}
}
