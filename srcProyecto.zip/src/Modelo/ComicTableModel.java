package Modelo;

import java.util.ArrayList;

public class ComicTableModel {
	private ArrayList<Comic> listaComics;
	private String[] columnas = {"ID","Nombre","Estado","Fecha de adquisici�n", "ID colecci�n"};
	
	
	
	//El constructor
	public ComicTableModel(ArrayList<Comic> listaComics) {
		super();
		this.listaComics = listaComics;
	}

	public int getRowCount() {
		return listaComics.size();
	}
	
	public int getColumnCount() {
		return columnas.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		Comic c= this.listaComics.get(rowIndex);
		switch (columnIndex) {
		case 0: {
			return c.GetIdComic();
		}
		case 1: {
			return c.GetNombreComic();	
		}
		case 2: return c.GetEstado();
		case 3: return c.GetFechaAdquisicion();
		case 4: return c.GetIdColeccion();
		default:
			return "-";
		}
	}

	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return columnas[column];
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
}


