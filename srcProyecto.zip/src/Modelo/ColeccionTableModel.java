package Modelo;

import java.util.ArrayList;

public class ColeccionTableModel {
	private ArrayList<Coleccion> listaColecciones;
	private String[] columnas = {"ID","Nombre"};
	
	
	
	//El constructor
	public ColeccionTableModel(ArrayList<Coleccion> listaColecciones) {
		super();
		this.listaColecciones = listaColecciones;
	}

	public int getRowCount() {
		return listaColecciones.size();
	}
	
	public int getColumnCount() {
		return columnas.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		Coleccion c= this.listaColecciones.get(rowIndex);
		switch (columnIndex) {
		case 0: {
			return c.GetIdColeccion();
		}
		case 1: {
			return c.GetNombreColeccion();	
		}
		default:
			return "-";
		}
	}

	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return columnas[column];
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
}

