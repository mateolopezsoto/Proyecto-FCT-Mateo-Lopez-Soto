package Modelo;

public class Coleccion {
	private int idColeccion;
	private String nombre_coleccion;
	
	public Coleccion (int id, String nombre) {
		this.idColeccion = id;
		this.nombre_coleccion = nombre;
	}
	
	public Coleccion (String nombre) {
		this.nombre_coleccion = nombre;
	}
	
	public Coleccion () {}
	
	public int GetIdColeccion () {
		return idColeccion;
	}
	
	public void SetIdColeccion (int id) {
		this.idColeccion = id;
	}
	
	public String GetNombreColeccion ()  {
		return nombre_coleccion;
	}
	
	public void SetNombreColeccion (String nombre) {
		this.nombre_coleccion = nombre;
	}
}
