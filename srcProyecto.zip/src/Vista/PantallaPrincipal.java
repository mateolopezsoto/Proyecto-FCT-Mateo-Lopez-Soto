package Vista;

import java.awt.EventQueue;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import Conexion.ConexionDatos;

import java.awt.event.ActionListener;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;

public class PantallaPrincipal {

	private JFrame frmPantallaPrincipal;
	HelpSet helpset;
	private HelpBroker browser;
	HelpSet helpsetGL;
	private HelpBroker browserGL;
	private JMenuItem ayudaMenuItem;
	private ResourceBundle rb;
	private JMenu ayudaMenu;
	private JMenuItem castellanoMenuItem;
	private JMenu coleccionesMenu;
	private JMenuItem gallegoMenuItem;
	private JMenu gestionMenu;
	private JMenu idiomaMenu;
	private JMenuItem informeColeccionesMenuItem;
	private JMenuItem nuevaColeccionMenuItem;
	private JMenuItem nuevoComicMenuItem;
	private JMenuItem tablaComicMenuItem;
	private JMenuItem tablaColeccionMenuItem;
	ConexionDatos cd = new ConexionDatos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaPrincipal window = new PantallaPrincipal();
					window.frmPantallaPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PantallaPrincipal() {
		initialize();
		abrirAyuda();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPantallaPrincipal = new JFrame();
		frmPantallaPrincipal.setTitle("Pantalla principal");
		frmPantallaPrincipal.setBounds(100, 100, 450, 300);
		frmPantallaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPantallaPrincipal.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JMenuBar menuBar = new JMenuBar();
		frmPantallaPrincipal.setJMenuBar(menuBar);
		
		idiomaMenu = new JMenu("Idioma");
		menuBar.add(idiomaMenu);
		
		castellanoMenuItem = new JMenuItem("Castellano");
		castellanoMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Locale.setDefault(new Locale("ES", "es"));
				traducir();
				abrirAyuda();
			}
		});
		idiomaMenu.add(castellanoMenuItem);
		
		gallegoMenuItem = new JMenuItem("Gallego");
		gallegoMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Locale.setDefault(new Locale("GL", "es"));
				traducir();
				abrirAyudaGL();
			}
		});
		idiomaMenu.add(gallegoMenuItem);
		
		ayudaMenu = new JMenu("Ayuda");
		menuBar.add(ayudaMenu);
		
		ayudaMenuItem = new JMenuItem("Ver ayuda");
		ayudaMenu.add(ayudaMenuItem);
		
		JMenu informesMenu = new JMenu("Informes");
		menuBar.add(informesMenu);
		
		informeColeccionesMenuItem = new JMenuItem("Informe colecciones");
		informeColeccionesMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cd.InformeColecciones();
			}
		});
		informesMenu.add(informeColeccionesMenuItem);
		
		JMenuItem informeComicsMenuItem = new JMenuItem("Informe comics");
		informeComicsMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cd.InformeComics();
			}
		});
		informesMenu.add(informeComicsMenuItem);
		
		JMenuItem informeFiltrosMenuItem = new JMenuItem("Informes con filtros");
		informeFiltrosMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InformeFiltros inf = new InformeFiltros();
				inf.traducir();
				inf.setVisible(true);
			}
		});
		informesMenu.add(informeFiltrosMenuItem);
		
		gestionMenu = new JMenu("Gesti\u00F3n");
		menuBar.add(gestionMenu);
		
		coleccionesMenu = new JMenu("Colecciones");
		gestionMenu.add(coleccionesMenu);
		
		nuevaColeccionMenuItem = new JMenuItem("Nueva colecci\u00F3n");
		nuevaColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NuevaColeccion nc = new NuevaColeccion();
				nc.traducir();
				nc.setVisible(true);
			}
		});
		coleccionesMenu.add(nuevaColeccionMenuItem);
		
		JMenuItem eliminarColeccionMenuItem = new JMenuItem("Eliminar colecci\u00F3n");
		eliminarColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EliminarColeccion ec = new EliminarColeccion();
				ec.setVisible(true);
			}
		});
		coleccionesMenu.add(eliminarColeccionMenuItem);
		
		tablaColeccionMenuItem = new JMenuItem("Tabla maestra");
		tablaColeccionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TablaMaestraColecciones tmc = new TablaMaestraColecciones();
				tmc.traducir();
				tmc.setVisible(true);
			}
		});
		coleccionesMenu.add(tablaColeccionMenuItem);
		
		JMenu comicsMenu = new JMenu("Comics");
		gestionMenu.add(comicsMenu);
		
		nuevoComicMenuItem = new JMenuItem("Nuevo comic");
		nuevoComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NuevoComic nco = new NuevoComic();
				nco.traducir();
				nco.setVisible(true);
			}
		});
		comicsMenu.add(nuevoComicMenuItem);
		
		JMenuItem eliminarComicMenuItem = new JMenuItem("Eliminar comic");
		eliminarComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EliminarComic eco = new EliminarComic();
				eco.setVisible(true);
			}
		});
		comicsMenu.add(eliminarComicMenuItem);
		
		tablaComicMenuItem = new JMenuItem("Tabla maestra");
		tablaComicMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TablaMaestraComics tmco = new TablaMaestraComics();
				tmco.traducir();
				tmco.setVisible(true);
			}
		});
		comicsMenu.add(tablaComicMenuItem);
	}

	public void traducir() {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String ayuda = rb.getString("ayudaMenu");
		 ayudaMenu.setText(ayuda);
		 String verAyuda = rb.getString("ayudaMenuItem");
		 ayudaMenuItem.setText(ayuda);
		 String castellano = rb.getString("castellanoMenuItem");
		 castellanoMenuItem.setText(castellano);
		 String colecciones = rb.getString("coleccionesMenu");
		 coleccionesMenu.setText(colecciones);
		 String gallego = rb.getString("gallegoMenuItem");
		 gallegoMenuItem.setText(gallego);
		 String gestion = rb.getString("gestionMenu");
		 gestionMenu.setText(gestion);
		 String idioma = rb.getString("idiomaMenu");
		 idiomaMenu.setText(idioma);
		 String informeC = rb.getString("informeColeccionesMenuItem");
		 informeColeccionesMenuItem.setText(informeC);
		 String nuevaC = rb.getString("nuevaColeccionMenuItem");
		 nuevaColeccionMenuItem.setText(nuevaC);
		 String nuevoC = rb.getString("nuevoComicMenuItem");
		 nuevoComicMenuItem.setText(nuevoC);
		 String tablaC = rb.getString("tablaMaestra");
		 tablaColeccionMenuItem.setText(tablaC);
		 String tablaCo = rb.getString("tablaMaestra");
		 tablaComicMenuItem.setText(tablaCo);
	}
	
	public void abrirAyuda() {
		try {
			 URL helpURL = this.getClass().getResource("/ayuda/help.hs");
				// URL helpURL = new URL("jar:file:jarproyecto.jar!/ayuda/help.hs");
				helpset = new HelpSet(null, helpURL);
				
				browser = helpset.createHelpBroker();
				
				browser.enableHelpOnButton(ayudaMenuItem, "inicio", helpset);		
			 
		 } catch (Exception e) {
			 e.printStackTrace();
		 }
	}
		
	public void abrirAyudaGL() {
		try {
			 URL helpURL = this.getClass().getResource("/ayuda/helpGL.hs");
				// URL helpURL = new URL("jar:file:jarproyecto.jar!/ayuda/helpGL.hs");
				helpset = new HelpSet(null, helpURL);
				
				browser = helpset.createHelpBroker();
				
				browser.enableHelpOnButton(ayudaMenuItem, "inicioGL", helpset);		
			 
		 } catch (Exception e) {
			 e.printStackTrace();
		 }
	}
	}

