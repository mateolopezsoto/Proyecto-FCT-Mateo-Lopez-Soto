package Vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import Conexion.ConexionDatos;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TablaMaestraComics extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private ResourceBundle rb;
	private JButton actualizarButton;
	private JTextField buscarTextField;
	private JButton buscarNombreButton;
	ConexionDatos cd = new ConexionDatos();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			TablaMaestraComics dialog = new TablaMaestraComics();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public TablaMaestraComics() {
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JScrollPane scrollPane = new JScrollPane();
			contentPanel.add(scrollPane, BorderLayout.CENTER);
			{
				table = new JTable();
				table.setEnabled(false);
				table.setRowSelectionAllowed(false);
				table.setBackground(SystemColor.inactiveCaptionBorder);
				table.setFont(new Font("Malgun Gothic", Font.PLAIN, 15));
				table.setFillsViewportHeight(true);
				table.setBorder(new LineBorder(new Color(0,0,0)));
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setBounds(60,23,506,209);
				scrollPane.setViewportView(table);
				cargarTabla();
			}
		}
		{
			JPanel panel = new JPanel();
			getContentPane().add(panel, BorderLayout.NORTH);
			{
				buscarTextField = new JTextField();
				panel.add(buscarTextField);
				buscarTextField.setColumns(10);
			}
			{
				buscarNombreButton = new JButton("Buscar nombre");
				panel.add(buscarNombreButton);
			}
			{
				JButton buscarColeccionButton = new JButton("Buscar colecci\u00F3n");
				panel.add(buscarColeccionButton);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton modificarButton = new JButton("Modificar comic");
				buttonPane.add(modificarButton);
				getRootPane().setDefaultButton(modificarButton);
			}
			{
				actualizarButton = new JButton("Actualizar tabla");
				actualizarButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						cargarTabla();
					}
				});
				buttonPane.add(actualizarButton);
			}
		}
	}

	public void traducir () {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String titulo = rb.getString("tituloTablaComic");
		 this.setTitle(titulo);
		 String actualizar = rb.getString("actualizarTablaButton");
		 actualizarButton.setText(actualizar);
		 String buscar = rb.getString("buscarNombreButton");
		 buscarNombreButton.setText(buscar);
	}
	
	public void cargarTabla () {
		DefaultTableModel modelo = new DefaultTableModel();
		modelo.setColumnIdentifiers(new Object[] {"ID Comic", "Nombre", "Estado", "Fecha de adquisici�n", "ID Colecci�n"});
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT idComic, nombre_comic, estado, fecha_adquisicion, idColeccion FROM comics";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			while (rs.next()) {
				modelo.addRow(new Object[] {rs.getInt("idComic"), rs.getString("nombre_comic"), rs.getString("estado"), rs.getDate("fecha_adquisicion"), rs.getInt("idColeccion")});
			}
			rs.close();
			s.close();
			table.setModel(modelo);
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar el driver de la bbdd");
		} catch (SQLException e) {
			System.out.println("Error en la ejecuci�n de la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch(SQLException e) {
				System.out.println("Error al cerrar la conexi�n");
			}
		}
	}
}
