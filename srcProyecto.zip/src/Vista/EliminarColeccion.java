package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Conexion.ConexionDatos;

import java.awt.Rectangle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EliminarColeccion extends JDialog {

	private final JPanel contentPanel = new JPanel();
	ConexionDatos cd = new ConexionDatos();
	private JComboBox eliminarComboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			EliminarColeccion dialog = new EliminarColeccion();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public EliminarColeccion() {
		setModal(true);
		setTitle("Eliminar colecci\u00F3n");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 1, 0, 0));
			{
				JLabel label = new JLabel("");
				panel.add(label);
			}
			{
				JLabel label = new JLabel("");
				panel.add(label);
			}
			{
				JLabel coleccionLabel = new JLabel("Colecci\u00F3n");
				coleccionLabel.setHorizontalAlignment(SwingConstants.CENTER);
				coleccionLabel.setHorizontalTextPosition(SwingConstants.CENTER);
				panel.add(coleccionLabel);
			}
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 1, 0, 0));
			{
				JLabel lblNewLabel_1 = new JLabel("");
				panel.add(lblNewLabel_1);
			}
			{
				JLabel lblNewLabel_2 = new JLabel("");
				panel.add(lblNewLabel_2);
			}
			{
			    eliminarComboBox = new JComboBox();
			    consultarColecciones(eliminarComboBox);
				panel.add(eliminarComboBox);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Eliminar colecci\u00F3n");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						eliminarColeccion();
						eliminarComicsColeccion();
						JOptionPane.showMessageDialog(null, "La colecci�n ha sido correctamente eliminada");
						eliminarComboBox.setSelectedIndex(-1);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}

	public void consultarColecciones (JComboBox comics) {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT concat(idColeccion, ' - ', nombre_coleccion) as datos FROM colecciones";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			while (rs.next()) {
				comics.addItem(rs.getString("datos"));
			}
			rs.close();
			s.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException e) {
			System.out.println("Error al ejecutar la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException e) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
	
	public void eliminarColeccion () {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "DELETE FROM colecciones WHERE idColeccion=?";
			PreparedStatement ps = c.prepareStatement(consulta);
			ps.setString(1, eliminarComboBox.getSelectedItem().toString().substring(0, 1));
			ps.executeUpdate();
			ps.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException exc) {
			System.out.println("Error al ejecutar la consulta");
			exc.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException exce) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
	
	public void eliminarComicsColeccion() {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "DELETE FROM comics WHERE idColeccion=?";
			PreparedStatement ps = c.prepareStatement(consulta);
			ps.setString(1, eliminarComboBox.getSelectedItem().toString().substring(0, 1));
			ps.executeUpdate();
			ps.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException exc) {
			System.out.println("Error al ejecutar la consulta");
			exc.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException exce) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
}
