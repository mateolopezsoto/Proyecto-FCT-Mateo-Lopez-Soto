package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Conexion.ConexionDatos;

import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;

public class NuevoComic extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField fechaTextField;
	private JTextField nombreTextField;
	private JTextField idColeccionTextField;
	private JLabel nombreLabel;
	private JLabel fechaLabel;
	private JButton anadirButton;
	private ResourceBundle rb;
	private JComboBox estadoComboBox;
	ConexionDatos cd = new ConexionDatos();
	public Date fecha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			NuevoComic dialog = new NuevoComic();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public NuevoComic() {
		actualizarComics();
		setModal(true);
		setTitle("Nuevo comic");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(4, 0, 10, 10));
			{
				nombreLabel = new JLabel("Nombre");
				nombreLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(nombreLabel);
			}
			{
				JLabel estadoLabel = new JLabel("Estado");
				estadoLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(estadoLabel);
			}
			{
				fechaLabel = new JLabel("Fecha de adquisici\u00F3n");
				fechaLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(fechaLabel);
			}
			{
				JLabel idColeccionLabel = new JLabel("ID de colecci\u00F3n");
				idColeccionLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(idColeccionLabel);
			}
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(4, 0, 10, 10));
			{
				nombreTextField = new JTextField();
				nombreTextField.setColumns(10);
				panel.add(nombreTextField);
			}
			{
				estadoComboBox = new JComboBox();
				estadoComboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Optimo", "Roto"}));
				panel.add(estadoComboBox);
			}
			{
				fechaTextField = new JTextField();
				fechaTextField.setColumns(10);
				panel.add(fechaTextField);
			}
			{
				idColeccionTextField = new JTextField();
				panel.add(idColeccionTextField);
				idColeccionTextField.setColumns(10);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				anadirButton = new JButton("A\u00F1adir comic");
				anadirButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (comprobar() == true) {
							String nombre = nombreTextField.getText();
							String estado = estadoComboBox.getSelectedItem().toString();
							String f = fechaTextField.getText();
							fecha.valueOf(f);
							String id = idColeccionTextField.getText();
							int idC = Integer.parseInt(id);
							insertarComic(nombre, estado, fecha, idC);
							actualizarComics();
							JOptionPane.showMessageDialog(null, "Comic a�adido correctamente");
							nombreTextField.setText("");
							estadoComboBox.setSelectedIndex(-1);
							fechaTextField.setText("");
							idColeccionTextField.setText("");
						}
					}
				});
				buttonPane.add(anadirButton);
				getRootPane().setDefaultButton(anadirButton);
			}
			{
				JButton cancelarButton = new JButton("Cancelar");
				cancelarButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						nombreTextField.setText("");
						estadoComboBox.setSelectedIndex(-1);
						fechaTextField.setText("");
						idColeccionTextField.setText("");
					}
				});
				buttonPane.add(cancelarButton);
			}
		}
	}

	public void traducir() {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String titulo = rb.getString("nuevoComicTitulo");
		 this.setTitle(titulo);
		 String nombre = rb.getString("nombreComicLabel");
		 nombreLabel.setText(nombre);
		 String fecha = rb.getString("fechaLabel");
		 fechaLabel.setText(fecha);
		 String anadir = rb.getString("anadirComicButton");
		 anadirButton.setText(anadir);
	}
	
	public void insertarComic(String n, String e, Date f, int idC) {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			c.setAutoCommit(false);
			String consulta = "INSERT INTO libreria.comics"
								+ "(nombre_comic, estado, fecha_adquisicion, idColeccion) VALUES "
								+ "( ?, ?, ?, ?);";
			PreparedStatement ps = c.prepareStatement(consulta, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, n);
			ps.setString(2, e);
			ps.setDate(3, f);
			ps.setInt(4, idC);
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
			int id = rs.getInt(1);
			System.out.println(id);
			c.commit();
			ps.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException exc) {
			System.out.println("Error al ejecutar la consulta");
			exc.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException exce) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
	
	public boolean comprobar() {
		if (nombreTextField.getText().equals("") || estadoComboBox.getSelectedIndex() == -1 || fechaTextField.getText().equals("") || idColeccionTextField.getText().equals("") ) {
			JOptionPane.showMessageDialog(null, "Faltan campos por cubrir"); 
			return false;
		}
		else {
			return true;
		}
	}
	
	public void actualizarComics () {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT idComic FROM comics";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			rs.close();
			s.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException e) {
			System.out.println("Error al ejecutar la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException e) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
}
