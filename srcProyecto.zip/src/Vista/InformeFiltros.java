package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.DateFormat;
import java.util.HashMap;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Conexion.ConexionDatos;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InformeFiltros extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField nombreTextField;
	private ResourceBundle rb;
	private JLabel idLabel;
	private JLabel nombreLabel;
	ConexionDatos cd = new ConexionDatos();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			InformeFiltros dialog = new InformeFiltros();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public InformeFiltros() {
		setModal(true);
		setTitle("Informes con filtros");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(5, 0, 0, 0));
			
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(lblNewLabel);
			
			idLabel = new JLabel("ID de la colecci\u00F3n");
			idLabel.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(idLabel);
			
			JLabel lblNewLabel_1 = new JLabel("");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(lblNewLabel_1);
			
			nombreLabel = new JLabel("Nombre del comic");
			nombreLabel.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(nombreLabel);
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(5, 0, 10, 10));
			
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(lblNewLabel);
			
			JComboBox idComboBox = new JComboBox();
			panel.add(idComboBox);
			
			JLabel lblNewLabel_1 = new JLabel("");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			panel.add(lblNewLabel_1);
			
			nombreTextField = new JTextField();
			panel.add(nombreTextField);
			nombreTextField.setColumns(10);
		}
		
		JPanel panel_1 = new JPanel();
		contentPanel.add(panel_1);
		
		JPanel panel = new JPanel();
		contentPanel.add(panel);
		panel.setLayout(new GridLayout(5, 0, 10, 10));
		
		JLabel lblNewLabel_2 = new JLabel("");
		panel.add(lblNewLabel_2);
		
		JButton informeIdButton = new JButton("Crear informe");
		panel.add(informeIdButton);
		
		JLabel lblNewLabel_3 = new JLabel("");
		panel.add(lblNewLabel_3);
		
		JButton informeNombreButton = new JButton("Crear informe");
		informeNombreButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (nombreTextField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "No has cubierto el campo de invitados");
				}
				else {
					String nombre = nombreTextField.getText();
					informeFiltros(nombre);
				}
			}
				
			}
		);
		panel.add(informeNombreButton);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
	
	public void traducir() {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String id = rb.getString("idLabel");
		 idLabel.setText(id);
		 String nombre = rb.getString("nombreComicLabel");
		 nombreLabel.setText(nombre);
	}
	
	public void informeFiltros (String nombre) {
		String informe ="./Informes/InformeNombreComic.jrxml";
		
		try {
			Connection conexion = cd.obtenerConexion();
			PreparedStatement st = conexion.prepareStatement("SELECT idComic, nombre_comic, estado, fecha_adquisicion, idColeccion FROM comics WHERE nombre_comic = ?");
			st.setString(1, nombre);
			ResultSet rs = st.executeQuery();
			
			JRResultSetDataSource ds = new JRResultSetDataSource(rs);
			
			HashMap<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("Nombre", nombre);
			
			JasperReport report = JasperCompileManager.compileReport(informe);
			
			JasperPrint visor = JasperFillManager.fillReport(report, parametros, ds);
			
			JasperViewer.viewReport(visor, false);
		
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
