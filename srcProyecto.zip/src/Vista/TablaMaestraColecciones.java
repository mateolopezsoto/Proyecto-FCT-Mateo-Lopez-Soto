package Vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import Conexion.ConexionDatos;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TablaMaestraColecciones extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private JButton modificarButton;
	private JButton actualizarButton;
	private ResourceBundle rb;
	private JPanel panel;
	private JTextField buscarTextField;
	private JButton buscarButton;
	ConexionDatos cd = new ConexionDatos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			TablaMaestraColecciones dialog = new TablaMaestraColecciones();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public TablaMaestraColecciones() {
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JScrollPane scrollPane = new JScrollPane();
			contentPanel.add(scrollPane, BorderLayout.CENTER);
			{
				table = new JTable();
				table.setRowSelectionAllowed(false);
				table.setEnabled(false);
				table.setBackground(SystemColor.inactiveCaptionBorder);
				table.setFont(new Font("Malgun Gothic", Font.PLAIN, 15));
				table.setFillsViewportHeight(true);
				table.setBorder(new LineBorder(new Color(0,0,0)));
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setBounds(60,23,506,209);
				scrollPane.setViewportView(table);
				cargarTabla();
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
			    modificarButton = new JButton("Modificar colecci\u00F3n");
				modificarButton.setActionCommand("OK");
				buttonPane.add(modificarButton);
				getRootPane().setDefaultButton(modificarButton);
			}
			{
			    actualizarButton = new JButton("Actualizar tabla");
			    actualizarButton.addActionListener(new ActionListener() {
			    	public void actionPerformed(ActionEvent e) {
			    		cargarTabla();
			    	}
			    });
				actualizarButton.setActionCommand("Cancel");
				buttonPane.add(actualizarButton);
			}
		}
		{
			panel = new JPanel();
			getContentPane().add(panel, BorderLayout.NORTH);
			{
				buscarTextField = new JTextField();
				buscarTextField.setColumns(10);
				panel.add(buscarTextField);
			}
			{
				buscarButton = new JButton("Buscar");
				panel.add(buscarButton);
			}
		}
	}
	
	public void traducir () {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String titulo = rb.getString("tituloTablaColeccion");
		 this.setTitle(titulo);
		 String actualizar = rb.getString("actualizarTablaButton");
		 actualizarButton.setText(actualizar);
	}

	public void cargarTabla () {
		DefaultTableModel modelo = new DefaultTableModel();
		modelo.setColumnIdentifiers(new Object[] {"ID Colecci�n", "Nombre"});
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT idColeccion, nombre_coleccion FROM colecciones";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			while (rs.next()) {
				modelo.addRow(new Object[] {rs.getInt("idColeccion"), rs.getString("nombre_coleccion")});
			}
			rs.close();
			s.close();
			table.setModel(modelo);
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar el driver de la bbdd");
		} catch (SQLException e) {
			System.out.println("Error en la ejecuci�n de la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch(SQLException e) {
				System.out.println("Error al cerrar la conexi�n");
			}
		}
	}
}
