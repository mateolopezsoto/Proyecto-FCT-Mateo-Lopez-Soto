package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Conexion.ConexionDatos;

import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EliminarComic extends JDialog {

	private final JPanel contentPanel = new JPanel();
	public JComboBox eliminarComboBox;
	ConexionDatos cd = new ConexionDatos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			EliminarComic dialog = new EliminarComic();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public EliminarComic() {
		setModal(true);
		setTitle("Eliminar comic");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 0, 0, 0));
			{
				JLabel lblNewLabel = new JLabel("");
				panel.add(lblNewLabel);
			}
			{
				JLabel lblNewLabel = new JLabel("");
				panel.add(lblNewLabel);
			}
			{
				JLabel eliminarLabel = new JLabel("Eliminar comic");
				eliminarLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(eliminarLabel);
			}
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 0, 0, 0));
			{
				JLabel lblNewLabel = new JLabel("");
				panel.add(lblNewLabel);
			}
			{
				JLabel lblNewLabel = new JLabel("");
				panel.add(lblNewLabel);
			}
			{
				eliminarComboBox = new JComboBox();
				consultarComic(eliminarComboBox);
				panel.add(eliminarComboBox);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton eliminarButton = new JButton("Eliminar comic");
				eliminarButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							eliminarComic();
							eliminarComboBox.setSelectedIndex(-1);
							consultarComic(eliminarComboBox);
					}
				});
				eliminarButton.setActionCommand("OK");
				buttonPane.add(eliminarButton);
				getRootPane().setDefaultButton(eliminarButton);
			}
		}
	}
	
	public void consultarComic (JComboBox comics) {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT concat(idComic, ' - ', nombre_comic) as datos FROM comics";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			while (rs.next()) {
				comics.addItem(rs.getString("datos"));
			}
			rs.close();
			s.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException e) {
			System.out.println("Error al ejecutar la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException e) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
	
	public void eliminarComic () {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "DELETE FROM comics WHERE idComic=?";
			PreparedStatement ps = c.prepareStatement(consulta);
			ps.setString(1, eliminarComboBox.getSelectedItem().toString().substring(0, 1));
			ps.executeUpdate();
			ps.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException exc) {
			System.out.println("Error al ejecutar la consulta");
			exc.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException exce) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
	
	public void actualizarComics () {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			String consulta = "SELECT idComic FROM comics";
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(consulta);
			rs.close();
			s.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException e) {
			System.out.println("Error al ejecutar la consulta");
			e.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException e) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}

}
