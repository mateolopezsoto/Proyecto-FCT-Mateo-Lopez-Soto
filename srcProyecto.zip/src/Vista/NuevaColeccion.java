package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Conexion.ConexionDatos;

import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NuevaColeccion extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField nombreTextField;
	private JLabel nombreLabel;
	private JButton anadirButton;
	private ResourceBundle rb;
	ConexionDatos cd = new ConexionDatos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			NuevaColeccion dialog = new NuevaColeccion();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public NuevaColeccion() {
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 0, 0, 0));
			{
				JLabel lblNewLabel_1 = new JLabel("");
				panel.add(lblNewLabel_1);
			}
			{
				JLabel lblNewLabel = new JLabel("");
				panel.add(lblNewLabel);
			}
			{
				nombreLabel = new JLabel("Nombre Colecci\u00F3n");
				nombreLabel.setHorizontalAlignment(SwingConstants.CENTER);
				panel.add(nombreLabel);
			}
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new GridLayout(6, 0, 0, 0));
			{
				JLabel lblNewLabel_4 = new JLabel("");
				panel.add(lblNewLabel_4);
			}
			{
				JLabel lblNewLabel_5 = new JLabel("");
				panel.add(lblNewLabel_5);
			}
			{
				nombreTextField = new JTextField();
				panel.add(nombreTextField);
				nombreTextField.setColumns(10);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				anadirButton = new JButton("A\u00F1adir colecci\u00F3n");
				anadirButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (!nombreTextField.getText().equals("")) {
							insertarColeccion(nombreTextField.getText());
							nombreTextField.setText("");
						}
						else {
							JOptionPane.showMessageDialog(null, "No has indicado un nombre para la colecci�n");
							nombreTextField.setText("");
						}
					}
				});
				anadirButton.setActionCommand("OK");
				buttonPane.add(anadirButton);
				getRootPane().setDefaultButton(anadirButton);
			}
			{
				JButton cancelarButton = new JButton("Cancelar");
				cancelarButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						nombreTextField.setText("");
					}
				});
				cancelarButton.setActionCommand("Cancel");
				buttonPane.add(cancelarButton);
			}
		}
	}
	
	public void traducir() {
		 rb = ResourceBundle.getBundle("resourceBundle.Idioma");
		 String titulo = rb.getString("nuevaColeccionTitulo");
		 this.setTitle(titulo);
		 String nombre = rb.getString("nombreColeccionLabel");
		 nombreLabel.setText(nombre);
		 String anadir = rb.getString("anadirColeccionButton");
		 anadirButton.setText(anadir);
	}

	public void insertarColeccion(String n) {
		Connection c = null;
		try {
			cd.CargarDriver();
			c = cd.obtenerConexion();
			c.setAutoCommit(false);
			String consulta = "INSERT INTO colecciones"
								+ "(nombre_coleccion) VALUES "
								+ "( ?);";
			PreparedStatement ps = c.prepareStatement(consulta, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, n);
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
			int id = rs.getInt(1);
			System.out.println(id);
			c.commit();
			ps.close();
		} catch (ClassNotFoundException ex) {
			System.out.println("Error al cargar la BBDD");
		} catch (SQLException exc) {
			System.out.println("Error al ejecutar la consulta");
			exc.printStackTrace();
		} finally {
			try {
				if (c != null && !c.isClosed())
					c.close();
			} catch (SQLException exce) {
				System.out.println("Error al cerrar la conexion");
			}
		}
	}
}
